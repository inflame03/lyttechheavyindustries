# About
These are the touch icons used on devices to help make the Web application look native.

The default images are taken from Google's [Web Starter Kit](https://github.com/h5bp/html5-boilerplate); cfr LICENSE.md file in this folder.
