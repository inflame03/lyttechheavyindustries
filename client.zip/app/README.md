# About
This folder is where ALL the code of your application should be located.
This is the main folder that the build system will care about.

# index.html
The index.html file is where the fun begins. Take a look at it to get an idea of how the application is bootstrapped.

The next piece of the puzzle is the core/boot.ts file which is the application entrypoint.
