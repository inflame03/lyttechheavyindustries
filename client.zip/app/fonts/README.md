# About
This folder should contain all Web fonts of your application (if any).
