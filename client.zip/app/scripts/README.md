# About
This folder can be used to put generic/utility code (prefer core if possible -- 'scripts' feels legacy :p).
