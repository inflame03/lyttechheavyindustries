# About
This folder is intended to contain all general services of your application.
One example could be a service responsible for managing translations.
