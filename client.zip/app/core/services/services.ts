"use strict";
// way to create a list all injectable classes
/*
import {BlahService} from 'components/posts/posts.service';

export let appServicesInjectables : Array<any> = [
	PostsService
];
*/
