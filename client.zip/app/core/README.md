# About
Should contain all main pieces of your application.
First and foremost, the *boot.ts* file, which is the entrypoint of your application.

This folder can also be used to store:
* common code: utilities and the like
* generic code (i.e., component agnostic): controllers/services/directives, ...
