# babu

## About
Created by the ModernWebDev Yeoman Generator

This project was created using the [ModernWebDev Yeoman Generator](https://github.com/dsebastien/modernWebDevGenerator) by [dSebastien](https://twitter.com/dSebastien).

## How to build
First, make sure that you have installed the required global npm packages: `npm install gulp --global --no-optional`.

Next, you also need to install the project dependencies using `npm run setup`.

For more details about the build, refer to the [ModernWebDevBuild](https://github.com/dsebastien/modernWebDevBuild) project documentation.
